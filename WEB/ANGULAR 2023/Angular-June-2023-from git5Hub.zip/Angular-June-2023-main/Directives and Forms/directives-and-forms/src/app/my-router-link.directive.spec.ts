import { MyRouterLinkDirective } from './my-router-link.directive';

describe('MyRouterLinkDirective', () => {
  it('should create an instance', () => {
    const directive = new MyRouterLinkDirective();
    expect(directive).toBeTruthy();
  });
});
