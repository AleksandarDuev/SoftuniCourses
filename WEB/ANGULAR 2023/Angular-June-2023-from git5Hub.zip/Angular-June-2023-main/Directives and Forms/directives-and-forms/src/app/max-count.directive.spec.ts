import { MaxCountDirective } from './max-count.directive';

describe('MaxCountDirective', () => {
  it('should create an instance', () => {
    const directive = new MaxCountDirective();
    expect(directive).toBeTruthy();
  });
});
