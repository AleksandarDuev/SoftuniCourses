import { MyStructuralDirective } from './my-structural.directive';

describe('MyStructuralDirective', () => {
  it('should create an instance', () => {
    const directive = new MyStructuralDirective();
    expect(directive).toBeTruthy();
  });
});
