import { HighlightOnMoveDirective } from './highlight-on-move.directive';

describe('HighlightOnMoveDirective', () => {
  it('should create an instance', () => {
    const directive = new HighlightOnMoveDirective();
    expect(directive).toBeTruthy();
  });
});
