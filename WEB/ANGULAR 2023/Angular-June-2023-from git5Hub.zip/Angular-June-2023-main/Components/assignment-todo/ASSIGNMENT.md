Conver HTML, CSS and JavaScript project into Angular project. Use components, directives and everything you know for Angular until now.

"assignment-todo" is the project ot use as starting point!
