OSI model: https://www.geeksforgeeks.org/layers-of-osi-model/

HTTP :https://dev.to/accreditly/http1-vs-http2-vs-http3-2k1c
