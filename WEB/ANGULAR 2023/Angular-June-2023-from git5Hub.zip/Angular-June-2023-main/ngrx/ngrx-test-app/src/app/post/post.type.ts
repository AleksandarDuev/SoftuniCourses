export interface Post {
  likes?: number;
  text?: string;
}

export interface PostState {
  post: Post;
}
