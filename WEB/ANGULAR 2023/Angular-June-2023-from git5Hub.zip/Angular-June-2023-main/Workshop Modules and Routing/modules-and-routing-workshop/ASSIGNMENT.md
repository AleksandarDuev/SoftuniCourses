// 1. Checkout my branch and run the application.
// 2. Add "Page Not Found" component.
// 3. Implement with local storage "Register" functionality and add it to the relevant place.
// 4. Make "POST" request to the db with "New Theme" component.
