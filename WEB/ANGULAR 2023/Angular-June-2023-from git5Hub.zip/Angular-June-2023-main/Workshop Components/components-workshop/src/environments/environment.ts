export const environment = {
  appUrl: 'http://localhost:3000/api', // domain -> will not be localhost in prod
};
