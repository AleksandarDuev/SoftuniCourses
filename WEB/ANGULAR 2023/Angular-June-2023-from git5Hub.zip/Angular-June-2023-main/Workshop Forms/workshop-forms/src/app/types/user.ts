export interface User {
  email: string;
  firstName: string;
  // phoneNumber: string;
  // password: string;
}
