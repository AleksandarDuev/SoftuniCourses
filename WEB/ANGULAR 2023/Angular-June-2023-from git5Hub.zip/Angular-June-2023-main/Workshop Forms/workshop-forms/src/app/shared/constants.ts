export const DEFAULT_EMAIL_DOMAINS = ["bg", "com"];
