import { AppEmailDirective } from './app-email.directive';

describe('AppEmailDirective', () => {
  it('should create an instance', () => {
    const directive = new AppEmailDirective();
    expect(directive).toBeTruthy();
  });
});
