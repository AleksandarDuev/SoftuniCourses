const Animal = require("../models/Animal");

exports.create = (animalData) => Animal.create(animalData);

exports.getAll = () => Animal.find().populate("owner");

exports.getOne = (animalId) => Animal.findById(animalId).populate("owner");

exports.updateAnimal = (animalId, animalData) =>
    Animal.findByIdAndUpdate(animalId, animalData);

exports.deleteAnimal = (animalId) => Animal.findByIdAndDelete(animalId);

exports.donate = async (animalId, userId) => {
    console.log("1");
    const animal = await Photo.findById(animalId);

    animal.donations.push(userId);

    return animal.save();
};
