const jwt = require("../lib/jwt");
const { SECRET, TOKEN_KEY } = require("../config/config");

exports.auth = async (req, res, next) => {
    const token = req.cookies[TOKEN_KEY];

    if (token) {
        try {
            const decodedToken = await jwt.verify(token, SECRET);
            req.user = decodedToken;
            res.locals.token = decodedToken;
            res.locals.isAuthenticated = true;

            next();
        } catch (error) {
            res.clearCookie(TOKEN_KEY);
            res.redirect("/users/login");
        }
    } else {
        next();
    }
};

exports.isAuthorized = (req, res, next) => {
    if (!req.user) {
        return res.redirect("/users/login");
    }

    next();
};
